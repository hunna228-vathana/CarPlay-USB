package com.ottocarlink

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.LinkedBlockingQueue

/** Plays the PCM audio (music, navigation, calls) sent by the box. */
class AudioOut {
    private class Player(rate: Int, channels: Int) {
        private val queue = LinkedBlockingQueue<ByteArray>(64)
        private val track: AudioTrack
        private val thread: Thread

        init {
            val mask = if (channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
            val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(min, rate * channels * 2 / 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            thread = Thread({
                try {
                    while (true) {
                        val b = queue.take()
                        track.write(b, 0, b.size)
                    }
                } catch (ignored: InterruptedException) {
                }
            }, "audio-out")
            thread.start()
        }

        fun push(pcm: ByteArray) {
            if (!queue.offer(pcm)) queue.clear()
        }

        fun release() {
            thread.interrupt()
            try {
                track.stop()
                track.release()
            } catch (ignored: Exception) {
            }
        }
    }

    private val players = HashMap<Int, Player>()

    private fun format(decodeType: Int): Pair<Int, Int> = when (decodeType) {
        1, 2 -> 44100 to 2
        3 -> 8000 to 1
        4 -> 48000 to 2
        5 -> 16000 to 1
        6 -> 24000 to 1
        7 -> 16000 to 1
        else -> 44100 to 2
    }

    @Synchronized
    fun play(decodeType: Int, pcm: ByteArray) {
        val p = players.getOrPut(decodeType) {
            val (rate, ch) = format(decodeType)
            Player(rate, ch)
        }
        p.push(pcm)
    }

    @Synchronized
    fun release() {
        players.values.forEach { it.release() }
        players.clear()
    }
}
