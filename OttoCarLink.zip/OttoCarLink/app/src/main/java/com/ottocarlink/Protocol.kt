package com.ottocarlink

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Settings you can change. The box streams video at this size. */
object Config {
    var width = 1280
    var height = 720
    var fps = 30
    var dpi = 240
}

/** Message types of the Carlinkit-style box protocol. */
object Msg {
    const val OPEN = 1
    const val PLUGGED = 2
    const val PHASE = 3
    const val UNPLUGGED = 4
    const val TOUCH = 5
    const val VIDEO = 6
    const val AUDIO = 7
    const val COMMAND = 8
    const val BT_ADDR = 10
    const val BT_PIN = 12
    const val BT_NAME = 13
    const val WIFI_NAME = 14
    const val DISCONNECT_PHONE = 15
    const val BT_PAIRED = 18
    const val MANUFACTURER = 20
    const val CLOSE = 21
    const val BOX_SETTINGS = 25
    const val SEND_FILE = 153
    const val HEARTBEAT = 170
    const val SW_VERSION = 204
}

/** Command ids sent inside a COMMAND message. */
object Cmd {
    const val MIC_CAR = 7
    const val FRAME = 12          // asks for a fresh key frame
    const val WIFI_24 = 24
    const val WIFI_5 = 25
    const val BACK = 106
    const val HOME = 200
    const val WIFI_ENABLE = 1000
    const val WIFI_CONNECT = 1002
}

object Proto {
    const val MAGIC = 0x55AA55AA
    const val HEADER = 16

    fun le(vararg v: Int): ByteArray {
        val b = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (x in v) b.putInt(x)
        return b.array()
    }

    fun packet(type: Int, payload: ByteArray = ByteArray(0)): ByteArray {
        val b = ByteBuffer.allocate(HEADER + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(MAGIC)
        b.putInt(payload.size)
        b.putInt(type)
        b.putInt(type.inv())
        b.put(payload)
        return b.array()
    }

    fun command(id: Int): ByteArray = packet(Msg.COMMAND, le(id))

    /** action: 14 = down, 15 = move, 16 = up. x and y are 0..10000. */
    fun touch(action: Int, x: Int, y: Int): ByteArray = packet(Msg.TOUCH, le(action, x, y, 0))

    fun file(path: String, content: ByteArray): ByteArray {
        val name = (path + "\u0000").toByteArray(Charsets.US_ASCII)
        return packet(Msg.SEND_FILE, le(name.size) + name + le(content.size) + content)
    }

    fun fileInt(path: String, value: Int): ByteArray = file(path, le(value))

    fun open(): ByteArray =
        packet(Msg.OPEN, le(Config.width, Config.height, Config.fps, 5, 4915200, 2, 2))

    fun boxSettings(): ByteArray {
        val json = "{\"mediaDelay\":300,\"syncTime\":${System.currentTimeMillis() / 1000}," +
            "\"androidAutoSizeW\":${Config.width},\"androidAutoSizeH\":${Config.height}}"
        return packet(Msg.BOX_SETTINGS, json.toByteArray(Charsets.UTF_8))
    }
}
