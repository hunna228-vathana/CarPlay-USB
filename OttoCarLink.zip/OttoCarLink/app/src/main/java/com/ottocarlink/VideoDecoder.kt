package com.ottocarlink

import android.media.MediaCodec
import android.media.MediaFormat
import android.view.Surface
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Decodes the H.264 stream from the box straight onto a Surface. */
class VideoDecoder(private val log: (String) -> Unit) {
    private var codec: MediaCodec? = null
    private var thread: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>(120)

    @Volatile private var running = false

    fun start(surface: Surface, width: Int, height: Int) {
        stop()
        try {
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
            fmt.setInteger("low-latency", 1)
            fmt.setInteger(MediaFormat.KEY_PRIORITY, 0)
            val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            c.configure(fmt, surface, null, 0)
            c.start()
            codec = c
            queue.clear()
            running = true
            val t = Thread({ loop(c) }, "video-decoder")
            thread = t
            t.start()
        } catch (e: Exception) {
            log("Video decoder failed to start: ${e.message}")
        }
    }

    fun submit(data: ByteArray) {
        if (!running) return
        if (!queue.offer(data)) {
            // too slow: drop the backlog to keep delay low, next key frame repairs the picture
            queue.clear()
        }
    }

    private fun loop(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running) {
                val data = queue.poll(20, TimeUnit.MILLISECONDS)
                if (data != null) {
                    val idx = c.dequeueInputBuffer(20_000)
                    if (idx >= 0) {
                        val buf = c.getInputBuffer(idx)
                        if (buf != null && data.size <= buf.capacity()) {
                            buf.clear()
                            buf.put(data)
                            c.queueInputBuffer(idx, 0, data.size, System.nanoTime() / 1000, 0)
                        } else {
                            c.queueInputBuffer(idx, 0, 0, 0, 0)
                            log("Video frame too large for decoder (${data.size} bytes).")
                        }
                    }
                }
                while (true) {
                    val out = c.dequeueOutputBuffer(info, 0)
                    if (out >= 0) c.releaseOutputBuffer(out, true) else break
                }
            }
        } catch (e: Exception) {
            if (running) log("Video decoder stopped: ${e.message}")
        }
    }

    fun stop() {
        running = false
        try { thread?.join(500) } catch (ignored: InterruptedException) {}
        thread = null
        try {
            codec?.stop()
            codec?.release()
        } catch (ignored: Exception) {
        }
        codec = null
        queue.clear()
    }
}
