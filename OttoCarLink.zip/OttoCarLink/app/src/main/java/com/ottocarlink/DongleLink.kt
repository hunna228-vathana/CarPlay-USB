package com.ottocarlink

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Talks to the box over USB. The phone is the USB host ("the car"),
 * the box is the USB device.
 */
class DongleLink(
    private val ctx: Context,
    private val log: (String) -> Unit,
    private val onVideo: (ByteArray) -> Unit,
    private val onAudio: (Int, ByteArray) -> Unit,
) {
    companion object {
        const val ACTION_PERM = "com.ottocarlink.USB_PERMISSION"
        const val BOX_VENDOR_ID = 0x1314
    }

    private class Found(val iface: UsbInterface, val inEp: UsbEndpoint, val outEp: UsbEndpoint)

    private val usb = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
    private var conn: UsbDeviceConnection? = null
    private var iface: UsbInterface? = null
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private val writeLock = Any()
    private var receiversOn = false

    @Volatile private var running = false
    private var videoFrames = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERM -> {
                    val dev = deviceFrom(i)
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                        open(dev)
                    } else {
                        log("USB permission was not given. Press Connect and tap OK.")
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    if (running) {
                        log("USB cable or box removed.")
                        close()
                    }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun deviceFrom(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private fun registerReceivers() {
        if (receiversOn) return
        val f = IntentFilter().apply {
            addAction(ACTION_PERM)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            ctx.registerReceiver(receiver, f)
        }
        receiversOn = true
    }

    private fun findBulk(dev: UsbDevice): Found? {
        for (n in 0 until dev.interfaceCount) {
            val itf = dev.getInterface(n)
            if (itf.interfaceClass == UsbConstants.USB_CLASS_HUB) continue
            var i: UsbEndpoint? = null
            var o: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) i = ep else o = ep
            }
            if (i != null && o != null) return Found(itf, i, o)
        }
        return null
    }

    /** Find the box and open it (asks for USB permission the first time). */
    fun connect() {
        registerReceivers()
        if (running) close()
        val devices = usb.deviceList.values.toList()
        if (devices.isEmpty()) {
            log("No USB device found. Check: OTG cable/adapter, box has power, cable carries data.")
            return
        }
        for (d in devices) {
            log(
                "USB device: vid=0x${d.vendorId.toString(16)} pid=0x${d.productId.toString(16)} " +
                    "${d.manufacturerName ?: ""} ${d.productName ?: ""}".trim()
            )
        }
        val target = devices.firstOrNull { it.vendorId == BOX_VENDOR_ID }
            ?: devices.firstOrNull { findBulk(it) != null }
        if (target == null) {
            log("No device with USB bulk endpoints found.")
            return
        }
        if (usb.hasPermission(target)) {
            open(target)
        } else {
            val intent = Intent(ACTION_PERM).setPackage(ctx.packageName)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(ctx, 0, intent, flags)
            log("Asking USB permission...")
            usb.requestPermission(target, pi)
        }
    }

    private fun open(dev: UsbDevice) {
        val found = findBulk(dev)
        if (found == null) {
            log("Device has no bulk in/out endpoints.")
            return
        }
        val c = usb.openDevice(dev)
        if (c == null) {
            log("Could not open USB device.")
            return
        }
        if (!c.claimInterface(found.iface, true)) {
            log("Could not claim USB interface.")
            c.close()
            return
        }
        conn = c
        iface = found.iface
        inEp = found.inEp
        outEp = found.outEp
        running = true
        videoFrames = 0
        log(
            "Box opened. IN=0x${found.inEp.address.toString(16)} " +
                "OUT=0x${found.outEp.address.toString(16)}. Starting session..."
        )
        Thread({ readLoop() }, "box-read").start()
        Thread({ sessionLoop() }, "box-session").start()
    }

    // ---------------------------------------------------------------- writing

    private fun write(data: ByteArray): Boolean {
        val c = conn ?: return false
        val ep = outEp ?: return false
        synchronized(writeLock) {
            var off = 0
            while (off < data.size) {
                val n = minOf(16384, data.size - off)
                val chunk = if (off == 0 && n == data.size) data else data.copyOfRange(off, off + n)
                val r = c.bulkTransfer(ep, chunk, chunk.size, 2000)
                if (r < 0) return false
                off += n
            }
        }
        return true
    }

    fun sendTouch(action: Int, x: Int, y: Int) {
        if (running) write(Proto.touch(action, x, y))
    }

    fun sendCommand(id: Int) {
        if (running) write(Proto.command(id))
    }

    // ---------------------------------------------------------------- session

    private fun sessionLoop() {
        try {
            write(Proto.fileInt("/tmp/screen_dpi", Config.dpi))
            write(Proto.open())
            write(Proto.boxSettings())
            write(Proto.command(Cmd.WIFI_ENABLE))
            write(Proto.command(Cmd.WIFI_5))
            write(Proto.command(Cmd.MIC_CAR))
            log("Init sent. Waiting for the box to answer...")
            Thread.sleep(1000)
            write(Proto.command(Cmd.WIFI_CONNECT))

            var tick = 0
            var failures = 0
            while (running) {
                if (write(Proto.packet(Msg.HEARTBEAT))) failures = 0 else failures++
                if (failures >= 3) {
                    log("Box does not answer writes. Connection lost.")
                    close()
                    return
                }
                if (tick % 3 == 2) write(Proto.command(Cmd.FRAME))
                tick++
                Thread.sleep(2000)
            }
        } catch (ignored: InterruptedException) {
        }
    }

    // ---------------------------------------------------------------- reading

    private fun readFully(buf: ByteArray, len: Int): Boolean {
        val c = conn ?: return false
        val ep = inEp ?: return false
        var off = 0
        var fastFails = 0
        while (running && off < len) {
            val want = minOf(16384, len - off)
            val t0 = System.nanoTime()
            val n = c.bulkTransfer(ep, buf, off, want, 1000)
            if (n > 0) {
                off += n
                fastFails = 0
            } else if (n < 0) {
                // timeout takes ~1s; an instant failure means the device is gone
                if ((System.nanoTime() - t0) < 100_000_000L) {
                    fastFails++
                    if (fastFails > 50) {
                        log("USB read keeps failing. Connection lost.")
                        close()
                        return false
                    }
                    try { Thread.sleep(5) } catch (ignored: InterruptedException) { return false }
                }
            }
        }
        return running && off == len
    }

    private fun readLoop() {
        val hdr = ByteArray(Proto.HEADER)
        while (running) {
            if (!readFully(hdr, Proto.HEADER)) break
            val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
            val magic = bb.int
            val len = bb.int
            val type = bb.int
            val check = bb.int
            if (magic != Proto.MAGIC || check != type.inv()) {
                log("Bad header from box (magic=0x${magic.toString(16)}). Skipping.")
                continue
            }
            if (len < 0 || len > 8_000_000) {
                log("Bad length $len for message type $type.")
                continue
            }
            val payload = ByteArray(len)
            if (len > 0 && !readFully(payload, len)) break
            try {
                handle(type, payload)
            } catch (e: Exception) {
                log("Error handling message $type: ${e.message}")
            }
        }
    }

    private fun handle(type: Int, p: ByteArray) {
        when (type) {
            Msg.VIDEO -> {
                if (p.size > 20) {
                    if (videoFrames == 0L) {
                        val bb = ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN)
                        log("Video started: ${bb.int}x${bb.int}")
                    }
                    videoFrames++
                    onVideo(p.copyOfRange(20, p.size))
                }
            }
            Msg.AUDIO -> {
                if (p.size > 16) {
                    val decodeType = ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN).int
                    onAudio(decodeType, p.copyOfRange(12, p.size))
                }
            }
            Msg.PLUGGED -> {
                val phoneType = if (p.size >= 4) ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN).int else -1
                log("Phone plugged into box (type $phoneType). Waiting for video...")
            }
            Msg.UNPLUGGED -> log("Phone unplugged from box.")
            Msg.PHASE -> {
                val ph = if (p.size >= 4) ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN).int else -1
                log("Phase $ph")
            }
            Msg.COMMAND -> {
                val id = if (p.size >= 4) ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN).int else -1
                log("Box command $id")
            }
            Msg.SW_VERSION, Msg.BT_NAME, Msg.WIFI_NAME, Msg.BT_ADDR, Msg.BT_PIN, Msg.MANUFACTURER ->
                log("Box info ($type): " + String(p, Charsets.UTF_8).filter { it.code in 32..126 })
            Msg.HEARTBEAT -> {}
            else -> log("Message type $type, ${p.size} bytes")
        }
    }

    // ---------------------------------------------------------------- closing

    fun close() {
        val wasRunning = running
        running = false
        try {
            iface?.let { conn?.releaseInterface(it) }
            conn?.close()
        } catch (ignored: Exception) {
        }
        conn = null
        iface = null
        inEp = null
        outEp = null
        if (wasRunning) log("Disconnected.")
    }

    fun release() {
        close()
        if (receiversOn) {
            try { ctx.unregisterReceiver(receiver) } catch (ignored: Exception) {}
            receiversOn = false
        }
    }
}
