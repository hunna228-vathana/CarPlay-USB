package com.ottocarlink

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var surfaceView: SurfaceView
    private val lines = ArrayDeque<String>()

    private val decoder = VideoDecoder { say(it) }
    private val audio = AudioOut()
    private var link: DongleLink? = null

    private fun say(msg: String) {
        runOnUiThread {
            lines.addLast(msg)
            while (lines.size > 120) lines.removeFirst()
            logView.text = lines.joinToString("\n")
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        surfaceView = SurfaceView(this)
        root.addView(
            surfaceView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(Color.GREEN)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        logScroll = ScrollView(this).apply {
            setBackgroundColor(0xAA000000.toInt())
            addView(logView)
        }
        root.addView(
            logScroll,
            FrameLayout.LayoutParams(dp(420), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START)
        )

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addButton(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.textSize = 12f
            b.setOnClickListener { action() }
            buttons.addView(b, LinearLayout.LayoutParams(dp(100), dp(48)))
        }
        addButton("Connect") { connectBox() }
        addButton("Home") { link?.sendCommand(Cmd.HOME) }
        addButton("Back") { link?.sendCommand(Cmd.BACK) }
        addButton("Log") {
            logScroll.visibility = if (logScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        root.addView(
            buttons,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.TOP
            )
        )
        setContentView(root)

        // keep the picture at the box's aspect ratio, centered
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val cw = r - l
            val ch = b - t
            if (cw > 0 && ch > 0) {
                var w = cw
                var h = w * Config.height / Config.width
                if (h > ch) {
                    h = ch
                    w = h * Config.width / Config.height
                }
                val lp = surfaceView.layoutParams as FrameLayout.LayoutParams
                if (lp.width != w || lp.height != h) {
                    lp.width = w
                    lp.height = h
                    surfaceView.layoutParams = lp
                }
            }
        }

        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                decoder.start(holder.surface, Config.width, Config.height)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                decoder.stop()
            }
        })

        surfaceView.setOnTouchListener { v, e ->
            val action = when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> 14
                MotionEvent.ACTION_MOVE -> 15
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> 16
                else -> -1
            }
            if (action > 0 && v.width > 0 && v.height > 0) {
                val x = (e.x.coerceIn(0f, v.width.toFloat()) / v.width * 10000).toInt()
                val y = (e.y.coerceIn(0f, v.height.toFloat()) / v.height * 10000).toInt()
                link?.sendTouch(action, x, y)
            }
            true
        }

        say("OttoCarLink ready. Plug the box into the phone with the USB cable, then press Connect.")
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connectBox()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connectBox()
    }

    private fun connectBox() {
        val l = link ?: DongleLink(
            this,
            { say(it) },
            { decoder.submit(it) },
            { type, pcm -> audio.play(type, pcm) }
        ).also { link = it }
        l.connect()
    }

    override fun onDestroy() {
        link?.release()
        decoder.stop()
        audio.release()
        super.onDestroy()
    }
}
